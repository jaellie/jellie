BGB Adventure 2 | extracted asset pack
Source sheet: 1536 x 1024 px (NOT 4K).
Files: 105 PNGs. Extraction from one composed AI image; some adjacent assets may have remnants or cropped parts.
Alpha transparency is approximate and should be visually inspected. Character poses are not animation-ready sprites.
Seamless check compares opposite border pixels (mean absolute RGB error). Low border error is NOT proof of seamless tiling; corner, pattern and repetition continuity require manual verification.
Tiles that fail border test: 17. Low-border-error tiles, not guaranteed seamless: 8.
NO tile in this pack is certified seamless. Modular platforms likewise need edge corrections.
For production, recreate or repair tiles and test tiled previews before using. See asset_manifest.csv.
